#include <stdio.h>
#include <string.h>
#include "scheduler.h"
#include "pcb.h"

#define MAX_READY 10
#define MLFQ_LEVELS 4

static char currentAlgorithm[10];
static int currentRunning = -1;

// RR-specific
static int timeQuantum = 1;
static int currentQuantum = 0;
static int rrQueue[MAX_READY];
static int rrFront = 0, rrRear = 0;

// MLFQ-specific
static int mlfqQueues[MLFQ_LEVELS][MAX_READY];
static int mlfqFront[MLFQ_LEVELS] = {0}, mlfqRear[MLFQ_LEVELS] = {0};
static int mlfqQuantum[MLFQ_LEVELS] = {1, 2, 4, 8};
static int mlfqQuantumCounter = 0;

void initScheduler(const char* algorithm, int quantum) {
    strcpy(currentAlgorithm, algorithm);
    currentRunning = -1;

    rrFront = rrRear = 0;
    timeQuantum = quantum;
    currentQuantum = 0;

    for (int i = 0; i < MLFQ_LEVELS; i++) {
        mlfqFront[i] = mlfqRear[i] = 0;
    }
    mlfqQuantumCounter = 0;
}

void addToReadyQueue(int pcbIndex) {
    if (strcmp(currentAlgorithm, "FCFS") == 0 || strcmp(currentAlgorithm, "RR") == 0) {
        if ((rrRear + 1) % MAX_READY != rrFront) {
            rrQueue[rrRear] = pcbIndex;
            rrRear = (rrRear + 1) % MAX_READY;
        }
    } else if (strcmp(currentAlgorithm, "MLFQ") == 0) {
        PCB pcb;
        readPCBFromMemory(pcbIndex, &pcb);
        int level = pcb.priority;
        int next = mlfqRear[level];
        mlfqQueues[level][next] = pcbIndex;
        mlfqRear[level] = (next + 1) % MAX_READY;
    }
}

int dequeueRR() {
    if (rrFront == rrRear) return -1;
    int val = rrQueue[rrFront];
    rrFront = (rrFront + 1) % MAX_READY;
    return val;
}

int dequeueMLFQ(int level) {
    if (mlfqFront[level] == mlfqRear[level]) return -1;
    int val = mlfqQueues[level][mlfqFront[level]];
    mlfqFront[level] = (mlfqFront[level] + 1) % MAX_READY;
    return val;
}

int getNextProcess() {
    if (strcmp(currentAlgorithm, "FCFS") == 0) {
        if (currentRunning != -1) return currentRunning;
        return dequeueRR();
    }

    if (strcmp(currentAlgorithm, "RR") == 0) {
        if (currentRunning == -1) {
            currentRunning = dequeueRR();
            currentQuantum = 0;
        }
        return currentRunning;
    }

    if (strcmp(currentAlgorithm, "MLFQ") == 0) {
        if (currentRunning == -1) {
            for (int level = 0; level < MLFQ_LEVELS; level++) {
                int candidate = dequeueMLFQ(level);
                if (candidate != -1) {
                    currentRunning = candidate;
                    mlfqQuantumCounter = 0;
                    return currentRunning;
                }
            }
        }
        return currentRunning;
    }

    return -1;
}

void onProcessBlocked(int pcbIndex) {
    if ((strcmp(currentAlgorithm, "RR") == 0 && pcbIndex == currentRunning) ||
        (strcmp(currentAlgorithm, "MLFQ") == 0 && pcbIndex == currentRunning)) {
        currentRunning = -1;
        currentQuantum = 0;
        mlfqQuantumCounter = 0;
    }
}

void onProcessUnblocked(int pcbIndex) {
    PCB pcb;
    readPCBFromMemory(pcbIndex, &pcb);
    printf("--------------------→P%d is unblocked\n", pcb.pid);
    addToReadyQueue(pcbIndex);
}

void markProcessFinished(int pcbIndex) {
    PCB pcb;
    readPCBFromMemory(pcbIndex, &pcb);
    pcb.state = TERMINATED;
    writePCBToMemory(pcbIndex, &pcb);

    if (pcbIndex == currentRunning) {
        currentRunning = -1;
        currentQuantum = 0;
        mlfqQuantumCounter = 0;
    }
}

void updateScheduler() {
    if (strcmp(currentAlgorithm, "RR") == 0) {
        currentQuantum++;
        if (currentQuantum >= timeQuantum && currentRunning != -1) {
            PCB pcb;
            readPCBFromMemory(currentRunning, &pcb);
            pcb.state = READY;
            writePCBToMemory(currentRunning, &pcb);
            addToReadyQueue(currentRunning);
            currentRunning = -1;
            currentQuantum = 0;
        }
    }

    if (strcmp(currentAlgorithm, "MLFQ") == 0 && currentRunning != -1) {
        mlfqQuantumCounter++;

        PCB pcb;
        readPCBFromMemory(currentRunning, &pcb);
        int level = pcb.priority;

        if (mlfqQuantumCounter >= mlfqQuantum[level]) {
            if (level < MLFQ_LEVELS - 1) {
                pcb.priority++;
            }
            pcb.state = READY;
            writePCBToMemory(currentRunning, &pcb);
            addToReadyQueue(currentRunning);
            printf("--------------------→P%d demoted to Q%d\n", pcb.pid, pcb.priority + 1);
            currentRunning = -1;
            mlfqQuantumCounter = 0;
        }
        
    }
}


const char* getSchedulerType() {
    return currentAlgorithm;
}
