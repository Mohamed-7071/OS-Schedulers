#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "process.h"
#include "memory.h"
#include "pcb.h"

#define PCB_SIZE 6  // adjust if your PCB grows

int loadProcessIntoMemory(const char* filename, int pid, int arrivalTime) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Error opening file %s\n", filename);
        return -1;
    }

    char line[100];

    // Reserve space: instructions + 3 vars + PCB (approx)
    int base = findFreeSegment(20);
    if (base == -1) {
        printf("Memory full for process %d\n", pid);
        fclose(file);
        return -1;
    }

    int i = base;

    // === Load instructions ===
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        char fullLine[120];
        sprintf(fullLine, "instruction:%s", line);
        writeToMemory(i++, fullLine);
    }
    fclose(file);

    // === Reserve variables ===
    const char* vars[] = {"a", "b", "filename"};
    for (int v = 0; v < 3; v++) {
        char varLine[100];
        sprintf(varLine, "%s:", vars[v]);
        writeToMemory(i++, varLine);
    }

    // === Reserve space for PCB (empty, just to define memory boundaries)
    int pcbStart = i;
    for (int j = 0; j < PCB_SIZE; j++) {
        writeToMemory(i++, "");  // placeholder
    }

    // === Create and store PCB
    PCB pcb;
    pcb.pid = pid;
    pcb.state = READY;
    pcb.priority = 1;
    pcb.pc = 0;
    pcb.memStart = base;
    pcb.memEnd = i - 1;

    writePCBToMemory(pcbStart, &pcb);

    return pcbStart;
}
