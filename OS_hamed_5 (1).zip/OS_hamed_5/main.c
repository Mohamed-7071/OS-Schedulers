#include <stdio.h>
#include <string.h>
#include "memory.h"
#include "mutex.h"
#include "pcb.h"
#include "process.h"
#include "interpreter.h"
#include "scheduler.h"

#define MAX_PROCESSES 3

char* programFiles[MAX_PROCESSES] = {
    "Program_3.txt",  //P1
    "Program_1.txt",  //P2
    "Program_2.txt"   //P3
};

int arrivalTimes[MAX_PROCESSES] = {0, 1, 3};
int loadedPCBs[MAX_PROCESSES] = {-1, -1, -1};
int nextToLoad = 0;

Mutex userInput, userOutput, file;

int main() {
    initMemory();
    initMutex(&userInput);
    initMutex(&userOutput);
    initMutex(&file);

    initScheduler("FCFS", 0);  // quantum is ignored for MLFQ
  // You can switch to "FCFS", 0

    int runningPCB = -1;
    PCB pcb;
    int completed[MAX_PROCESSES] = {0};
    int currentCycle = 0;

    while (1) {
        // Load arriving processes
        while (nextToLoad < MAX_PROCESSES && arrivalTimes[nextToLoad] <= currentCycle){
            int pcbIndex = loadProcessIntoMemory(programFiles[nextToLoad], nextToLoad + 1, arrivalTimes[nextToLoad]);
            loadedPCBs[nextToLoad] = pcbIndex;
            addToReadyQueue(pcbIndex);
            nextToLoad++;
        }

        // Ask scheduler for next process if none is running
        if (runningPCB == -1) {
            runningPCB = getNextProcess();
            if (runningPCB != -1) {
                readPCBFromMemory(runningPCB, &pcb);
                pcb.state = RUNNING;
                writePCBToMemory(runningPCB, &pcb);
            }
        }
        

        if (runningPCB != -1) {
            readPCBFromMemory(runningPCB, &pcb);
            char* instrLine = readFromMemory(pcb.memStart + pcb.pc);
            if (instrLine && strncmp(instrLine, "instruction:", 12) == 0) {
                printf("Cycle %d: P%d should be executing %s\n", currentCycle, pcb.pid, instrLine + 12);
            }
        
            int result = executeInstruction(runningPCB, currentCycle);
        
            if (result == 0) {
                // Blocked
                readPCBFromMemory(runningPCB, &pcb);
                pcb.state = BLOCKED;
                writePCBToMemory(runningPCB, &pcb);
                onProcessBlocked(runningPCB);
                runningPCB = -1;
            } else if (result == -1) {
                // Finished
                readPCBFromMemory(runningPCB, &pcb);
                completed[pcb.pid - 1] = 1;
                markProcessFinished(runningPCB);
                runningPCB = -1;
            }
        }

        // Let scheduler update (RR/MLFQ)
        updateScheduler();
// Force preemption if the scheduler demoted or replaced the process
  // Force context switch if the process was demoted or replaced
if (runningPCB != -1 &&
    (strcmp(getSchedulerType(), "MLFQ") == 0 || strcmp(getSchedulerType(), "RR") == 0)) {

    PCB nextPcb;
    int candidate = getNextProcess();
    if (candidate != runningPCB) {
        runningPCB = -1;
    }
}



        

        // === ✅ FINAL FIX HERE: check if all done ===
        int allDone = 1;
        for (int i = 0; i < MAX_PROCESSES; i++) {
            if (!completed[i]) {
                allDone = 0;
                break;
            }
        }

        if (allDone) break;

        currentCycle++;
    }


    printf("\nSimulation completed in %d cycles.\n", currentCycle);
    return 0;
}
