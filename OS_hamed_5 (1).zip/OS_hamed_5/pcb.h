#ifndef PCB_H
#define PCB_H

#define READY 0
#define RUNNING 1
#define BLOCKED 2
#define TERMINATED 3

typedef struct {
    int pid;
    int state;
    int priority;
    int pc;
    int memStart;
    int memEnd;
} PCB;

void writePCBToMemory(int index, PCB* pcb);
void readPCBFromMemory(int index, PCB* pcb);

#endif
