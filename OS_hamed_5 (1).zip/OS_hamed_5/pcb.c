#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pcb.h"
#include "memory.h"

void writePCBToMemory(int index, PCB* pcb) {
    char buffer[MEMORY_WORD_LENGTH];
    sprintf(buffer, "PID:%d", pcb->pid); writeToMemory(index++, buffer);
    sprintf(buffer, "State:%d", pcb->state); writeToMemory(index++, buffer);
    sprintf(buffer, "Priority:%d", pcb->priority); writeToMemory(index++, buffer);
    sprintf(buffer, "PC:%d", pcb->pc); writeToMemory(index++, buffer);
    sprintf(buffer, "Start:%d", pcb->memStart); writeToMemory(index++, buffer);
    sprintf(buffer, "End:%d", pcb->memEnd); writeToMemory(index++, buffer);
}

void readPCBFromMemory(int index, PCB* pcb) {
    sscanf(readFromMemory(index++), "PID:%d", &pcb->pid);
    sscanf(readFromMemory(index++), "State:%d", &pcb->state);
    sscanf(readFromMemory(index++), "Priority:%d", &pcb->priority);
    sscanf(readFromMemory(index++), "PC:%d", &pcb->pc);
    sscanf(readFromMemory(index++), "Start:%d", &pcb->memStart);
    sscanf(readFromMemory(index++), "End:%d", &pcb->memEnd);
}
