#ifndef PROCESS_H
#define PROCESS_H

#include "memory.h"
#include "pcb.h"

#define MAX_PROGRAM_LINES 20
#define MAX_LINE_LENGTH 100

typedef struct {
    int pid;
    int arrivalTime;
    char filename[50];
} ProcessMeta;

int loadProcessIntoMemory(const char* filename, int pid, int arrivalTime);

#endif
