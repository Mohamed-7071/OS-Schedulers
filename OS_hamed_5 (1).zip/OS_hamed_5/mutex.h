#ifndef MUTEX_H
#define MUTEX_H

#include <stdbool.h>

#define MAX_BLOCKED 10

typedef struct {
    bool locked;
    int owner; // PCB index of owner
    int blocked[MAX_BLOCKED];
    int blockedCount;
} Mutex;

void initMutex(Mutex* mtx);
bool semWait(Mutex* mtx, int pcbIndex);  // returns false if blocked
void semSignal(Mutex* mtx);              // unblocks if any process is waiting
int popBlocked(Mutex* mtx);

#endif
