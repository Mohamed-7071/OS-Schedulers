#ifndef INTERPRETER_H
#define INTERPRETER_H

int executeInstruction(int pcbIndex, int cycle);

#endif
