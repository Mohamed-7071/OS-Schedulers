#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "interpreter.h"
#include "memory.h"
#include "pcb.h"
#include "mutex.h"

extern Mutex userInput, userOutput, file;

char* getVariableValue(const char* varName, int start, int end) {
    static char buffer[MEMORY_WORD_LENGTH];
    for (int i = start; i <= end; i++) {
        // only consider non-empty slots
        if (memory[i][0] != '\0') {
            // find the colon
            char* colon = strchr(memory[i], ':');
            if (colon) {
                // check that the name before the colon matches varName
                size_t nameLen = colon - memory[i];
                if (strlen(varName) == nameLen && strncmp(memory[i], varName, nameLen) == 0) {
                    // copy everything after the colon into buffer
                    strncpy(buffer, colon + 1, MEMORY_WORD_LENGTH - 1);
                    buffer[MEMORY_WORD_LENGTH - 1] = '\0';
                    return buffer;
                }
            }
        }
    }
    // not found -> default "0"
    strcpy(buffer, "0");
    return buffer;
}


void setVariableValue(const char* varName, const char* value, int start, int end) {
    for (int i = start; i <= end; i++) {
        if (strchr(memory[i], ':')) {
            char name[30], dummy[70];
            sscanf(memory[i], "%[^:]:%s", name, dummy);
            if (strcmp(name, varName) == 0) {
                char newLine[100];
                sprintf(newLine, "%s:%s", name, value);
                writeToMemory(i, newLine);
                return;
            }
        }
    }

    for (int i = start; i <= end; i++) {
        if (strcmp(memory[i], "") == 0) {
            char newLine[100];
            sprintf(newLine, "%s:%s", varName, value);
            writeToMemory(i, newLine);
            return;
        }
    }
}




int executeInstruction(int pcbIndex, int cycle) {
    PCB pcb;
    readPCBFromMemory(pcbIndex, &pcb);

    int instrIndex = pcb.memStart + pcb.pc;
    char* memLine = readFromMemory(instrIndex);
    if (!memLine || strncmp(memLine, "instruction:", 12) != 0) return -1;

    char instr[100];
    strcpy(instr, memLine + 12);

    char* token = strtok(instr, " \n");
    if (!token) return -1;

    // assign x y
    // assign x y
if (strcmp(token, "assign") == 0) {
    char* var = strtok(NULL, " ");
    char* val = strtok(NULL, " ");
    if (!var || !val) return -1;

    // 1) assign x input
    if (strcmp(val, "input") == 0) {
        semWait(&userInput, pcbIndex);

        char input[100] = "";
        FILE* f = fopen("input_buffer.txt", "r");
        if (f) {
            // Read GUI-provided input
            if (fgets(input, sizeof(input), f)) {
                input[strcspn(input, "\n")] = '\0';
            }
            fclose(f);
            // clear buffer so it's single-use
            f = fopen("input_buffer.txt", "w"); fclose(f);
        }

        // Fallback to console if none in file
        if (strlen(input) == 0) {
            printf("Please enter a value for %s: ", var);
            fflush(stdout);
            if (fgets(input, sizeof(input), stdin))
                input[strcspn(input, "\n")] = '\0';
        }

        setVariableValue(var, input, pcb.memStart, pcb.memEnd);
        semSignal(&userInput);
    }

    // 2) assign x readFile y
    else if (strcmp(val, "readFile") == 0) {
        char* fileVar = strtok(NULL, " ");
        if (!fileVar) return -1;

        char* filename = getVariableValue(fileVar, pcb.memStart, pcb.memEnd);
        FILE* f = fopen(filename, "r");
        if (f) {
            char content[100] = "";
            if (fgets(content, sizeof(content), f)) {
                content[strcspn(content, "\n")] = '\0';
            }
            fclose(f);
            setVariableValue(var, content, pcb.memStart, pcb.memEnd);
        } else {
            printf("Error: cannot open file '%s'\n", filename);
            setVariableValue(var, "0", pcb.memStart, pcb.memEnd);
        }
    }

    // 3) assign x y (normal variable copy or literal)
    else {
        char* resolved = getVariableValue(val, pcb.memStart, pcb.memEnd);
        setVariableValue(var, resolved, pcb.memStart, pcb.memEnd);
    }

    pcb.pc++;
}


    // print x
    else if (strcmp(token, "print") == 0) {
        char* var = strtok(NULL, " ");
        char* val = getVariableValue(var, pcb.memStart, pcb.memEnd);
        printf("Output: %s\n", val);
        pcb.pc++;
    }

    // printFromTo x y
    else if (strcmp(token, "printFromTo") == 0) {
        char* x = strtok(NULL, " ");
        char* y = strtok(NULL, " ");
        int from = atoi(getVariableValue(x, pcb.memStart, pcb.memEnd));
        int to = atoi(getVariableValue(y, pcb.memStart, pcb.memEnd));
        for (int i = from; i <= to; i++) printf("%d ", i);
        printf("\n");
        pcb.pc++;
    }

    // semWait resource
    else if (strcmp(token, "semWait") == 0) {
        char* r = strtok(NULL, " ");
        bool acquired = false;
        if (strcmp(r, "userInput") == 0) acquired = semWait(&userInput, pcbIndex);
        else if (strcmp(r, "userOutput") == 0) acquired = semWait(&userOutput, pcbIndex);
        else if (strcmp(r, "file") == 0) acquired = semWait(&file, pcbIndex);

        if (acquired) {
            pcb.pc++;
            writePCBToMemory(pcbIndex, &pcb);
            return 1;
        } else {
            return 0;
        }
    }

    // semSignal resource
    else if (strcmp(token, "semSignal") == 0) {
        char* r = strtok(NULL, " ");
        if (strcmp(r, "userInput") == 0) semSignal(&userInput);
        else if (strcmp(r, "userOutput") == 0) semSignal(&userOutput);
        else if (strcmp(r, "file") == 0) semSignal(&file);
        pcb.pc++;
    }

    // readFile x
    else if (strcmp(token, "readFile") == 0) {
        char* var = strtok(NULL, " ");
        char* filename = getVariableValue(var, pcb.memStart, pcb.memEnd);
        FILE* f = fopen(filename, "r");
        if (f) {
            char content[100];
            fscanf(f, "%s", content);
            setVariableValue(var, content, pcb.memStart, pcb.memEnd);
            fclose(f);
        } else {
            printf("Error reading file '%s'\n", filename);
        }
        pcb.pc++;
    }

    // writeFile x y
    else if (strcmp(token, "writeFile") == 0) {
        char* fnameVar = strtok(NULL, " ");
        char* dataVar = strtok(NULL, " ");
        
        char fname[100], data[100];
        strcpy(fname, getVariableValue(fnameVar, pcb.memStart, pcb.memEnd));
        strcpy(data, getVariableValue(dataVar, pcb.memStart, pcb.memEnd));
    
        FILE* f = fopen(fname, "w");
        if (f) {
            fprintf(f, "%s", data);
            fclose(f);
        }
        pcb.pc++;
    }
    
    
    
    

    writePCBToMemory(pcbIndex, &pcb);
    return 1;
}
