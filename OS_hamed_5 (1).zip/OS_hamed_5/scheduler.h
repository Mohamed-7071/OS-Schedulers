#ifndef SCHEDULER_H
#define SCHEDULER_H

void initScheduler(const char* algorithm, int quantum);
void addToReadyQueue(int pcbIndex);
int getNextProcess(); // returns the next process to run
void onProcessBlocked(int pcbIndex);
void onProcessUnblocked(int pcbIndex);
void updateScheduler(); // call this each cycle to handle quantum expiration
void markProcessFinished(int pcbIndex);
const char* getSchedulerType();



#endif
