#ifndef MEMORY_H
#define MEMORY_H

#define MEMORY_SIZE 60
#define MEMORY_WORD_LENGTH 100

extern char memory[MEMORY_SIZE][MEMORY_WORD_LENGTH];

void initMemory();
int findFreeSegment(int size);
void writeToMemory(int index, const char* content);
char* readFromMemory(int index);

#endif
