#include "mutex.h"
#include "pcb.h"
#include "scheduler.h"
#include <stdio.h>


void initMutex(Mutex* mtx) {
    mtx->locked = false;
    mtx->owner = -1;
    mtx->blockedCount = 0;
}

bool semWait(Mutex* mtx, int pcbIndex) {

    if (!mtx->locked) {
        mtx->locked = true;
        mtx->owner = pcbIndex;
     
        return true;
    } else if (mtx->owner == pcbIndex) {
        // Already owns it — allow without blocking
       
        return true;
    } else {
        if (mtx->blockedCount < MAX_BLOCKED) {
            mtx->blocked[mtx->blockedCount++] = pcbIndex;

            PCB pcb;
            readPCBFromMemory(pcbIndex, &pcb);
            pcb.state = BLOCKED;
            writePCBToMemory(pcbIndex, &pcb);

           
            return false;
        }
        
        return false;
    }
}


void semSignal(Mutex* mtx) {
    if (mtx->blockedCount > 0) {
        int unblockedPCBIndex = popBlocked(mtx);

        PCB pcb;
        readPCBFromMemory(unblockedPCBIndex, &pcb);
        pcb.state = READY;
        writePCBToMemory(unblockedPCBIndex, &pcb);

        onProcessUnblocked(unblockedPCBIndex);  // ✅ put back in ready queue

        mtx->owner = unblockedPCBIndex;
        mtx->locked = true;
    } else {
        mtx->locked = false;
        mtx->owner = -1;
    }
}




int popBlocked(Mutex* mtx) {
    int id = mtx->blocked[0];
    for (int i = 1; i < mtx->blockedCount; i++) {
        mtx->blocked[i - 1] = mtx->blocked[i];
    }
    mtx->blockedCount--;
    return id;
}
