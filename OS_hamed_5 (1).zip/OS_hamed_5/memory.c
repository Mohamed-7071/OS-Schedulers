#include <stdio.h>
#include <string.h>
#include "memory.h"

char memory[MEMORY_SIZE][MEMORY_WORD_LENGTH];

void initMemory() {
    for (int i = 0; i < MEMORY_SIZE; i++) {
        strcpy(memory[i], "");
    }
}

int findFreeSegment(int size) {
    for (int i = 0; i <= MEMORY_SIZE - size; i++) {
        int free = 1;
        for (int j = i; j < i + size; j++) {
            if (strcmp(memory[j], "") != 0) {
                free = 0;
                break;
            }
        }
        if (free) return i;
    }
    return -1;
}

void writeToMemory(int index, const char* content) {
    if (index >= 0 && index < MEMORY_SIZE) {
        strncpy(memory[index], content, MEMORY_WORD_LENGTH);
    }
}

char* readFromMemory(int index) {
    if (index >= 0 && index < MEMORY_SIZE) {
        return memory[index];
    }
    return NULL;
}
